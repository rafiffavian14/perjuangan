Beberapa hal yang perlu diketahui

- Yang diubah adalah file dg extensi *.lyx

- Isilah di menu Document -> Setting -> Latex Preamble
  Beberapa variabel yang penting (nama variable sudah cukup menjelaskan)

\newcommand{\Judul}{Beternak bebek dengan menggunakan metoda Agile dan pendekatan Usability}
\newcommand{\Penulis}{Jagoan Neon}
\newcommand{\NPM}{01234567}
\newcommand{\NIRM}{98432324243}
\newcommand{\JenisTulisan}{Skripsi}
\newcommand{\Gelar}{Sarjana Teknik}
\newcommand{\Jurusan}{Teknik Informatika}
\newcommand{\Prodi}{Teknik Informatika}
\newcommand{\Tahun}{2020}
\newcommand{\Bulan}{November}
\newcommand{\Tanggal}{24}
\newcommand{\Kota}{Jakarta}
\newcommand{\KataKunci}{Teori antrian, model antrian, (FIFO/$\sim$/$\sim$)}
\newcommand{\KoordinatorPI}{Dr. Batman Suratman}
\newcommand{\KetuaJurusan}{Prof. Dr.-Ing. Adang Suhendra}
\newcommand{\Pembimbing}{Dr. Abc SSi, MSc}
\newcommand{\Ringkasan}{Tulis ringkasan skripsi, pi, atau apa dengan bahasa yang jelas, lugas dan
menggambarkan secara singkat tulisan ini.  Sebaiknya tidak lebih dari 150 kata
dan sudah menjelaskan dari permasalahan, pembahasan dan penutup.}
\newcommand{\JumlahPustaka}{8}
\newcommand{\JumlahHalaman}{80}
\newcommand{\JumlahHalamanDepan}{10}
\newcommand{\TahunPustaka}{2006-2016}
%%
%% Keterangan administratif sidang sarjana
%%
\newcommand{\TanggalSidang}{14 Februari 1998}
\newcommand{\TanggalLulus}{14 Februari 1998}
\newcommand{\TanggalSah}{6 April 1998}
\newcommand{\PejabatBagianSidang}{Drs. Edi Sukirman, MM}


- Logo Gunadarma letakkan di direktori setingkat

- file hypenation koreksi made-hypen.tex harus diletakkan pada direktori yang setingkat. File ini bisa saja diubah ditambahi bila menemukan pemenggalan yang tidak tepat.

- Pada bagian Abstraksi hati-hati terutama yang ada code "LaTeX" (ERT berwarna merah).  Beberapa paragraf pada bagian abstraksi memiliki spasi single.
  Pada bagian yang ada \noindent setelahnya ada spasi 

- Spasi dokumen ini adalah one-and-half (saya memutuskan tidak pakai double, terlalu membuang kertas)


